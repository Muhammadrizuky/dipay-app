import logo from './logo.svg';
import './App.css';
import './assets/css/content.css'
import Route from './routes'
import { BrowserRouter as Router } from 'react-router-dom'
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
		<div className='App'>
			<Router>
				<Route />
			</Router>
		</div>
	)
}

export default App;
