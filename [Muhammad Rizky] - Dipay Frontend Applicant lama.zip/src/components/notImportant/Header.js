import React, { useState, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import Navbar from 'react-bootstrap/Navbar'
import Container from 'react-bootstrap/Container'
import { Link } from 'react-router-dom'

function Header() {

    const { username } = useSelector((state) => state.login)

    console.log(username)

    const [login, setLogin] = useState(false)

    useEffect(() => {
        if(username !== null){
            setLogin(true)
        }else{
            setLogin(false)
        }
    })

    console.log(login)

    return(
        <Navbar className="header">
            <Container>
                <Link to = "/" exact>
                    <Navbar.Brand>Dipay Blog</Navbar.Brand>
                </Link>
                <Navbar.Toggle />
                <Navbar.Collapse className="justify-content-end">
                    {login != true ? (
                        <Link to = "/login">
                            <Navbar.Text>
                                You're not logged in
                            </Navbar.Text>
                        </Link>
                    ) : (
                        <Navbar.Text>
                            {username}
                        </Navbar.Text>
                    )}
                
                </Navbar.Collapse>
            </Container>
        </Navbar>
    )
}

export default Header