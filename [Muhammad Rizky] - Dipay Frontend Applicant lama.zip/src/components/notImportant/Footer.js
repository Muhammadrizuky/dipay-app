import React from 'react'

function Footer() {
    const getYear = () => {
        const year = new Date().getFullYear()
        return year
    }

    return(
            <footer className='mt-5'>
                <div className='container text-center'>
                    {getYear()} Copyright Muhammad Rizky &#169; All right reserved
                </div>
            </footer>
    )
}

export default Footer