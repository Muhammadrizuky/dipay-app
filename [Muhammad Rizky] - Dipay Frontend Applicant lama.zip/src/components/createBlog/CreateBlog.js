import React, { useState, useEffect } from 'react'
import { Form, Card, Button } from 'react-bootstrap'
import { useSelector, useDispatch } from 'react-redux'
import { v4 as uuidv4 } from 'uuid'
import blog from '../../reducers/blog'
import { useHistory, Link } from 'react-router-dom'
import { createBlog } from '../../actions/blogAct'

export default function CreateBlog() {
    const history = useHistory()
	const dispatch = useDispatch()
	const { isLogin } = useSelector((state) => state.login)
    const [blog, setBlog] = useState({
        title: "",
        description: "",
    })

    useEffect(() => {
        if(!isLogin) {
            history.push('/login')
        }else{
            return
        }
    }, [isLogin])

    const today = new Date()
    const dateToday = today.getDay() + "/" + today.getMonth() 
    + "/" + today.getFullYear() + " at " 
    + today.getHours() + ":" 
    + today.getMinutes()

    const handleForm = (e) => {
        e.preventDefault()

        const id = uuidv4()
        const dataBlog = {
            id: id,
            title: blog.title,
            date: dateToday,
            description: blog.description,
        }

        dispatch(createBlog(dataBlog))
        history.push('/')
    }

    return(
        <>
            <div className="content">
                <Card className="card-blog">
                    <Card.Body className="blog-content">
                        <Form className="" onSubmit={(e) => handleForm(e)}>
                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                <Form.Label>Title</Form.Label>
                                <Form.Control
                                    className="input-titleBlog"
                                    type="text"
                                    placeholder="Masukan title..."
                                    onChange={(e) => setBlog({...blog, title: e.target.value})}    
                                />
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea1">
                                <Form.Label>Description</Form.Label>
                                <Form.Control
                                    className="input-textArea"
                                    as="textarea"
                                    placeholder="Masukan Description..."
                                    onChange={(e) => setBlog({...blog, description: e.target.value})}
                                />
                            </Form.Group>

                            <Form.Group>
								<Button variant='primary' type='submit'>
									Submit
								</Button>
								<Link to='/' className='btn ml-3'>
									Go back
								</Link>
							</Form.Group>
                        </Form>
                    </Card.Body>
                </Card>
            </div>
        </>
    )
}