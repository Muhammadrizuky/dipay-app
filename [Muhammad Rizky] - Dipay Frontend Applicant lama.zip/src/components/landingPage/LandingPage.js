import React from 'react'
import { Card, Button } from 'react-bootstrap'
import { Link, useHistory } from 'react-router-dom'
import { useSelector, useDispatch } from 'react-redux'

export default function LandingPage() {
    const dispatch = useDispatch()
    const history = useHistory()

    const { datas } = useSelector((state) => state.blog)
    const { isLogin } = useSelector((state) => state.login)

    const data = [
        ["Muhammad Rizky", "Lorem ipsum sir dolor"],
        ["Kevin Altstein", "Hello it's me Muhammad Rizky"],
    ]

    const today = new Date()
    const date = today.getDate() + '-' + (today.getMonth() + 1) + '-' + today.getFullYear()

    return(
        <div className="content">
            <div className="landingPage-content">
				<Link to='/create-blog' stlye={{display:'flex'}}>
					<Button className='create-blog' >Create new blog</Button>
				</Link>
			</div>
            {datas.map((items, idx) => {
                return(
                    <Card className="card-content">
                        <Card.Header>{items.title}</Card.Header>
                        <Card.Body>
                            <Card.Text>
                                {items.description}
                            </Card.Text>
                        </Card.Body>
                        <Card.Footer>{items.date}</Card.Footer>
                    </Card>
                )
            })}
        </div>
    )
}