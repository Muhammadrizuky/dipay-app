import React, { useState, useEffect } from 'react'
import { Card, Form, Button } from 'react-bootstrap'
import { useHistory } from 'react-router'
import { useDispatch, useSelector } from 'react-redux'
import { isLoginAct, isLoginLoading } from '../../actions/loginAct'

export default function Login() {
    const history = useHistory()
    const dispatch = useDispatch()
    const [ username, setUsername ] = useState("")

    const { isLodaing, isLogin } = useSelector((state) => state.login)

    const handleChange = (e) => {
        setUsername(e.target.value)
    }

    useEffect(() => {
        if(isLogin) history.push('/create-blog')
    }, [isLogin])

    const handleSubmit = (e) => {
        e.preventDefault()
        dispatch(isLoginLoading())
        setTimeout(() => {
            dispatch(isLoginAct(username))
            history.push('/create-blog')
        }, 4000)
    }


    return(
        <>
            <div className="content">
                <Card className="card-login">
                    <Card.Header>Login</Card.Header>
                    <Card.Body>
                        <Form className="form-login" onSubmit={(e) => handleSubmit(e)}>
                            <Form.Group className="mb-3" controlId="formBasicEmail">
                                <Form.Label>Email address</Form.Label>
                                <Form.Control className="input-form" type="username" placeholder="Enter Email" onChange={(e) => {handleChange(e)}} />
                            </Form.Group>

                            <Form.Group className="mb-3" controlId="formBasicPassword">
                                <Form.Label>Password</Form.Label>
                                <Form.Control type="password" className="input-form"  placeholder="Password"/>
                            </Form.Group>
                            <Button variant="primary" className="button-login" type="submit">
                                Submit
                            </Button>
                        </Form>
                    </Card.Body>
                </Card> 
            </div>
        </>
    )
}